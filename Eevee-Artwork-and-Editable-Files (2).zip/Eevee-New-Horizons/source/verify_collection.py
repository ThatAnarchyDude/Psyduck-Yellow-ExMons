"""Verify scope, offline artwork, layout and complete PDF text recovery."""
from pathlib import Path
from html.parser import HTMLParser
import base64
import hashlib
import json
import re
import struct
import unicodedata
import fitz

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/'source/collection.json').read_text())
LAYOUT=json.loads((ROOT/'source/layout-check.json').read_text())
TYPES={'Normal','Fire','Water','Electric','Grass','Ice','Fighting','Poison','Ground','Flying','Psychic','Bug','Rock','Ghost','Dragon','Dark','Steel','Fairy'}
ordinary=D['ordinary_existing']+D['ordinary_new']
shared=D['mega']
special=D['mega_special']
forms=shared+special
entries=ordinary+forms
assert len(D['ordinary_new'])==10
assert len([p for p in D['ordinary_new'] if p['type'] in TYPES])==9
assert len(ordinary)==19 and len(shared)==18 and len(special)==1 and len(forms)==19 and len(entries)==38
assert len({p['entry'] for p in entries})==38
assert {p['type'] for p in ordinary}==TYPES|{'Stellar'}
assert {p['type'] for p in shared}==TYPES
assert special[0]['name']=='Mega Novareon' and special[0]['type']=='Stellar' and special[0]['sources']==['Novareon']
assert next(p for p in ordinary if p['type']=='Stellar')['name']=='Novareon'
assert D['stellar_stone']['name']=='Novareonite'
assert [p['name'] for p in ordinary if p['type']=='Normal']==['Eevee']
assert next(p for p in forms if p['type']=='Normal')['sources']==['Eevee']
for form in forms:
    source=next(p for p in ordinary if p['name']==form['sources'][0])
    assert source['type']==form['type']
assert all(p['name'].endswith('eon') for p in D['ordinary_new'])
assert len(list((ROOT/'art').glob('*.png')))==4
assert not list((ROOT/'art').glob('*original*'))
assert not (ROOT/'drafts').exists()
assert LAYOUT['dex_entries']==38 and LAYOUT['embedded_artwork']==4
assert LAYOUT['images_loaded']
assert all(not p['footer_overlap'] and not p['horizontal_overflow'] and p['bottom_space_px']>=20 for p in LAYOUT['pages'])

baseline=json.loads((ROOT/'source/core-preservation.json').read_text())
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
assert all(hashlib.sha256((ROOT/'art'/n).read_bytes()).hexdigest()==v for n,v in baseline['artwork'].items())
assert hashlib.sha256(D['eonite']['appearance'].encode()).hexdigest()==baseline['eonite_appearance']
assert hashlib.sha256(D['mega_design'].encode()).hexdigest()==baseline['mega_eevee_design']
core_ordinary=[p for p in ordinary if p['type'] in TYPES]
assert digest(core_ordinary)==baseline['standard_ordinary_specs']
assert digest(shared)==baseline['shared_mega_specs']
current_entries={(p.get('name','Mega Eevee')+' / '+p['type']):hashlib.sha256(p['entry'].encode()).hexdigest() for p in entries}
assert len(baseline['entries'])==36
assert all(current_entries[k]==v for k,v in baseline['entries'].items())

revision=baseline['novareon_revision']
assert revision['authorized_source_changes']==['/mega_special/0/design','/stellar_stone/appearance']
preserved=D|{'mega_special':[{k:v for k,v in p.items() if k!='design'} if p['name']=='Mega Novareon' else p for p in special],
             'stellar_stone':{k:v for k,v in D['stellar_stone'].items() if k!='appearance'}}
assert digest(preserved)==revision['preserved_collection_sha256']
assert {k:digest(v) for k,v in preserved.items()}==revision['preserved_json_subrecords']
assert len(revision['entries'])==38 and current_entries==revision['entries']
applied=ROOT/revision['applied_artwork']
assert hashlib.sha256(applied.read_bytes()).hexdigest()==revision['approved_sha256']
assert struct.unpack('>II',applied.read_bytes()[16:24])==(1536,1024)
for key,expected_hash in [('approved_preview',revision['approved_sha256']),('original_backup',revision['original_sha256'])]:
    local=ROOT/revision[key]
    if local.exists():
        assert hashlib.sha256(local.read_bytes()).hexdigest()==expected_hash
design=special[0]['design']
appearance=D['stellar_stone']['appearance']
assert hashlib.sha256(design.encode()).hexdigest()==revision['authorized_description_hashes']['/mega_special/0/design']['after_sha256']
assert hashlib.sha256(appearance.encode()).hexdigest()==revision['authorized_description_hashes']['/stellar_stone/appearance']['after_sha256']
for phrase in ['broad, convex plush fan tail','lowered and close','rounded depth','body-matching petrol-blue field','thin gold trim',
               'short, broad body-blue furry root','central blue inter-wedge spaces','without a pointed connector or outer-edge attachment',
               'Eight curved painted-fur motifs','white at top, green, vivid blue, purple, black at bottom, yellow, orange and red',
               'inward tapers swirl clockwise','white bending picture-right and black picture-left']:
    assert phrase in design,phrase
for phrase in ['front-on circular Mega Stone','equal height and width','smooth round perimeter','fine facets',
               'ivory six-rayed star','copper elliptical loop','two tiny copper knots','tiny clear prismatic wedge',
               'stay exactly the same before, during and after activation']:
    assert phrase in appearance,phrase
assert 'cushion-cut' not in appearance
assert 'three ivory wedges' in next(p for p in ordinary if p['name']=='Novareon')['design']

class Document(HTMLParser):
    def __init__(self):
        super().__init__();self.images=[];self.alts=[];self.data=[]
    def handle_starttag(self,tag,attrs):
        if tag=='img':
            attributes=dict(attrs)
            self.images.append(attributes['src'])
            self.alts.append(attributes.get('alt',''))
    def handle_data(self,data):self.data.append(data)

h=Document();h.feed((ROOT/'Eevee-New-Horizons.html').read_text())
assert len(h.images)==4 and all(s.startswith('data:image/png;base64,') for s in h.images)
actual=[hashlib.sha256(base64.b64decode(s.split(',',1)[1])).digest() for s in h.images]
expected=[hashlib.sha256(p.read_bytes()).digest() for p in sorted((ROOT/'art').glob('*.png'))]
assert actual==expected
assert 'three-wedge fan tail' in h.alts[3]
for phrase in ['rounded petrol-blue fan','eight clockwise fur motifs','black bottom wedge','broad gradual rump-to-center junction',
               'circular smoked-blue Novareonite','ivory six-ray star','copper elliptical inner orbit']:
    assert phrase in h.alts[3],phrase
md=(ROOT/'Eevee-New-Horizons.md').read_text()
assert sum(line.startswith('> ') for line in md.splitlines())==38
for local in re.findall(r'!\[[^\]]*\]\(([^)]+)\)',md):assert (ROOT/local).is_file()

def norm(s):return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',s)).strip()
pdf=fitz.open(ROOT/'Eevee-New-Horizons.pdf')
pdf_text=norm(' '.join(p.get_text() for p in pdf))
missing=[p.get('name','Mega Eevee')+' / '+p['type'] for p in entries if norm(p['entry']) not in pdf_text]
assert not missing,missing
assert len(pdf)==len(LAYOUT['pages'])==15
for text in [md,' '.join(h.data),pdf_text,json.dumps(D)]:
    for obsolete in ['five ivory wedges','five-wedge fan tail','broad black fan tail','rounded black fan',
                     'body-colored dark blue at bottom','cushion-cut Mega Stone']:
        assert obsolete not in text,obsolete
    assert not re.search(r'thirty-five|thirty-six|35 original|36 original|17 Mega|seventeen Mega|seventeen ruff|coordinator|legal clearance|nineteen ordinary types|19 ordinary types',text,re.I)
    for left,right in [('Norm','eon'),('Side','reon'),('Side','reonite'),('Ast','reon'),('Stellar','eon')]:
        assert (left+right).lower() not in text.lower()
assert 'Source: Eevee · single Normal type' in pdf_text
assert norm(design) in re.sub(r'(?<=\w)-\s+(?=\w)','-',pdf_text)
assert norm(appearance) in re.sub(r'(?<=\w)-\s+(?=\w)','-',pdf_text)

artifact_hashes={name:{'bytes':(ROOT/name).stat().st_size,'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest()}
                 for name in [revision['applied_artwork'],'Eevee-New-Horizons.md','Eevee-New-Horizons.html','Eevee-New-Horizons.pdf']}

report={
    'result':'PASS',
    'new_evolutions':10,
    'new_standard_type_evolutions':9,
    'ordinary_family_species':19,
    'standard_type_coverage':18,
    'special_stellar_fan_branch':True,
    'shared_mega_eevee_forms':18,
    'personal_mega_forms':1,
    'mega_forms_total':19,
    'normal_mega_source':'Eevee',
    'unique_original_entries':38,
    'complete_entries_recovered_from_pdf':38,
    'pdf_pages':15,
    'final_illustrated_boards':4,
    'accepted_core_entries_preserved':36,
    'all_38_original_entries_unchanged':True,
    'source_json_changes_limited_to_mega_design_and_novareonite_appearance':True,
    'authorized_source_exceptions':revision['authorized_source_changes'],
    'preserved_json_subrecords':list(revision['preserved_json_subrecords']),
    'ordinary_novareon_source_design_unchanged':True,
    'novareonite_mechanics_and_other_source_fields_unchanged':True,
    'novareonite_circular_appearance_updated_as_authorized':True,
    'approved_artwork_applied_byte_exact':True,
    'approved_artwork_sha256':revision['approved_sha256'],
    'approved_artwork_native_resolution':[1536,1024],
    'original_artwork_backup_sha256':revision['original_sha256'],
    'mega_novareon_eight_fur_motifs_and_central_attachment_documented':True,
    'mega_novareon_blue_field_black_bottom_and_broad_gradual_root_documented':True,
    'mega_novareon_full_description_recovered_from_pdf':True,
    'novareonite_full_appearance_recovered_from_pdf':True,
    'artifact_hashes':artifact_hashes,
    'accepted_three_art_boards_bit_identical':True,
    'accepted_standard_species_and_shared_mega_specs_unchanged':True,
    'eonite_appearance_unchanged':True,
    'shared_mega_eevee_design_unchanged':True,
    'stellar_final_names_consistent':True,
    'html_artwork_embedded_and_matches_final_pngs':True,
    'all_markdown_artwork_links_resolve':True,
    'all_pages_clear_of_footers':True,
    'minimum_content_to_footer_gap_px':min(p['bottom_space_px'] for p in LAYOUT['pages']),
    'obsolete_artwork_excluded':True,
    'manual_art_review':[
        'Four-species and five-species boards inspected for labels, silhouettes, anatomy and palette.',
        'Final Mega board inspected: eighteen accents including Normal, one shared Fire-example body, separate invariant Eonite with eighteen fixed inclusions.',
        'Normal ruff gem is pearl white with a ring; its source is base Eevee.',
        'Final original-style fourth board applied byte-for-byte at native resolution: rounded petrol-blue fan, eight clockwise fur motifs with black bottom, broad gradual central junction, and circular Novareonite with six-ray star and copper inner orbit.',
        'Actual PDF pages 12, 13 and 14 visually reviewed: final plate, complete updated Mega description, circular-stone appearance, original entries, activation rules and footer clearance.'
    ],
    'incomplete_items':[],
    'work_continuing':False
}
(ROOT/'source/verification-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
