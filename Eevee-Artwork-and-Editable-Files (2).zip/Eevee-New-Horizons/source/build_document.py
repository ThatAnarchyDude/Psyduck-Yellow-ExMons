"""Build the offline fan-design collection from its editable content source."""
from pathlib import Path
import base64
import html
import json
import re

ROOT = Path(__file__).resolve().parents[1]
D = json.loads((ROOT / 'source/collection.json').read_text())
ORDER = ['Normal','Fire','Water','Electric','Grass','Ice','Fighting','Poison','Ground','Flying','Psychic','Bug','Rock','Ghost','Dragon','Dark','Steel','Fairy']
EXISTING = D['ordinary_existing']
NEW_ALL = D['ordinary_new']
NEW = [p for p in NEW_ALL if p['type'] in ORDER]
STELLAR = next(p for p in NEW_ALL if p['type'] == 'Stellar')
PERSONAL = D['mega_special'][0]
STONE = D['stellar_stone']
MEGA = D['mega']
BY_TYPE = {p['type']: p for p in EXISTING + NEW}
COLORS = {p['type']: p['hex'] for p in MEGA} | {'Stellar':'#446a7d'}
FILES = ['01-new-evolutions.png','02-new-evolutions.png','03-mega-convergence.png','04-novareon-stellar-branch.png']
STELLAR_ART_ALT = 'Original petrol-blue and ivory Novareon with a three-wedge fan tail; Mega Novareon with a rounded petrol-blue fan, eight clockwise fur motifs including a black bottom wedge, and a broad gradual rump-to-center junction; circular smoked-blue Novareonite with an ivory six-ray star and copper elliptical inner orbit.'
ESC = html.escape

assert len(NEW) == 9 and len(EXISTING) == 9 and len(MEGA) == 18
assert len(NEW_ALL) == 10 and len(D['mega_special']) == 1
assert set(BY_TYPE) == set(ORDER)
assert all(x['name'].endswith('eon') for x in NEW_ALL)
assert len({x['entry'] for x in EXISTING + NEW_ALL + MEGA + D['mega_special']}) == 38
assert all(len(x['sources']) == 1 for x in MEGA)
assert set(x['type'] for x in MEGA) == set(ORDER)

def badge(t):
    return f'<span class="badge" style="--type:{COLORS[t]}">{ESC(t)}</span>'

def gem(t, size=48):
    """An exact diagram, separate from the generated painted artwork."""
    motif = {
        'Normal':'<circle cx="32" cy="32" r="16"/>',
        'Fire':'<path d="M32 15c1 11-11 11-9 21 0 6 5 11 11 11 9 0 14-9 9-17-1 6-5 6-5 6 2-10-7-13-6-21Z"/>',
        'Water':'<path d="M32 16C28 24 20 32 20 38a12 12 0 0 0 24 0c0-6-8-14-12-22Z"/>',
        'Electric':'<path d="m35 13-17 23h13l-3 16 19-26H34Z"/>',
        'Grass':'<path d="M20 43c-5-17 7-23 25-24 0 19-8 29-25 24Z"/><path d="m20 44 20-20"/>',
        'Ice':'<path d="M32 15v34M17 23l30 18M17 41l30-18M27 19l5 5 5-5M27 45l5-5 5 5"/>',
        'Fighting':'<path d="m21 21 22 22M43 21 21 43"/>',
        'Poison':'<circle cx="32" cy="23" r="4"/><circle cx="23" cy="39" r="4"/><circle cx="41" cy="39" r="4"/>',
        'Ground':'<path d="M18 27h28M18 38h28"/>',
        'Flying':'<path d="M17 35h22c12 0 11-17 1-17-7 0-8 10-2 10M20 43h23"/>',
        'Psychic':'<path d="M32 33c-1-6 8-7 8-1 0 12-19 12-20 0-2-19 28-20 28 0 0 16-22 24-33 10"/>',
        'Bug':'<path d="M28 47c1-14-5-22-10-25M36 47c-1-14 5-22 10-25"/><circle cx="18" cy="22" r="2"/><circle cx="46" cy="22" r="2"/>',
        'Rock':'<path d="m32 18 17 28H15Z"/>',
        'Ghost':'<path d="M40 17a17 17 0 1 0 0 30c-16 1-21-23 0-30Z"/>',
        'Dragon':'<path d="m17 42 15-20 15 20-15-9Z"/>',
        'Dark':'<circle cx="32" cy="32" r="16"/><path d="M39 18c-15 5-15 23 0 28"/>',
        'Steel':'<path d="m24 18-8 14 8 14h16l8-14-8-14Z"/>',
        'Fairy':'<path d="m32 14 5 13 13 5-13 5-5 13-5-13-13-5 13-5Z"/>'
    }[t]
    c = COLORS[t]
    engraving = '#655f55' if t == 'Normal' else '#fffaf0'
    return (f'<svg class="gem" width="{size}" height="{size}" viewBox="0 0 64 64" role="img" aria-label="{ESC(t)} ruff gem">'
        f'<path fill="{c}" stroke="#726d64" stroke-width="1" d="M19 4h26l15 15v26L45 60H19L4 45V19Z"/>'
        '<path d="m19 4 5 10h16l5-10M4 19l10 5v16L4 45m15 15 5-10h16l5 10m15-41-10 5v16l10 5" fill="none" stroke="#fff" opacity=".42"/>'
        f'<g fill="none" stroke="{engraving}" stroke-width="3.1" stroke-linecap="round" stroke-linejoin="round">{motif}</g></svg>')

def art(index, caption, alt):
    data = base64.b64encode((ROOT / 'art' / FILES[index]).read_bytes()).decode()
    return f'<figure><img class="board" src="data:image/png;base64,{data}" alt="{ESC(alt)}"><figcaption>{caption}</figcaption></figure>'

def section_title(kicker, title, subtitle=''):
    return f'<div class="kicker">{kicker}</div><h2>{title}</h2>' + (f'<p class="deck">{subtitle}</p>' if subtitle else '')

def dex(entry):
    return f'<blockquote class="dex-entry">{ESC(entry)}</blockquote>'

def new_record(p, compact=False):
    return f'''<article class="species-card {'compact' if compact else ''}" style="--type:{COLORS[p['type']]}">
      <div class="card-title"><h3>{p['name']}</h3>{badge(p['type'])}</div>
      <div class="category">{p['category']}</div>
      <p class="etym"><strong>Name.</strong> {ESC(p['derivation'])}</p>
      <p><strong>Visual design.</strong> {ESC(p['design'])}</p>
      <div class="entry-label">Original Pokédex entry</div>{dex(p['entry'])}
    </article>'''

def mega_record(p):
    return f'''<article class="mega-card" style="--type:{p['hex']}">
      <div class="mega-title">{gem(p['type'])}<div><h3>Mega Eevee</h3>{badge(p['type'])}</div></div>
      <p class="source"><strong>Source:</strong> {p['sources'][0]} · single {p['type']} type</p>
      <p class="accent"><strong>Ruff gem:</strong> {p['color'].lower()} · {p['motif'].lower()}</p>
      <div class="entry-label">Original Pokédex entry</div>{dex(p['entry'])}
    </article>'''

pages = []
def page(body, cls=''):
    n = len(pages) + 1
    pages.append(f'<section class="sheet {cls}" id="page-{n}"><div class="running">EEVEE / NEW HORIZONS <span>UNOFFICIAL FAN DESIGN COLLECTION</span></div>{body}<footer><span>New Horizons · Fan concept</span><span>{n:02d}</span></footer></section>')

intro = 'Nine new evolutions complete all eighteen ordinary types. Novareon adds a special Stellar branch with its own Mega form and fixed Mega Stone.'
page(f'''<div class="kicker cover-kicker">AN UNOFFICIAL POKÉMON FAN COLLECTION</div>
  <h1>Eevee:<br><em>New Horizons</em></h1>
  <p class="cover-deck">{D['subtitle']}</p>
  {art(0,'PLATE I · Brawleon / Zephyreon / Venomeon / Duneon','Four original fan-designed Eeveelutions in separate painted habitats: Fighting, Flying, Poison and Ground.')}
  <p class="cover-intro">{intro}</p>
  <div class="stats"><div><b>18 + ✦</b><span>types + Stellar</span></div><div><b>10</b><span>new species</span></div><div><b>19</b><span>Mega forms</span></div><div><b>38</b><span>original entries</span></div></div>
  <p class="small">Original fan concepts and AI-generated illustrations. Not official Pokémon artwork or game content.</p>''', 'cover')

rows=[]
for t in ORDER:
    p=BY_TYPE[t]
    origin = 'Base species' if t=='Normal' else ('New fan evolution' if p in NEW else 'Existing evolution')
    result = f'Mega Eevee · {t}'
    rows.append(f'<tr><td>{badge(t)}</td><td><strong>{p["name"]}</strong></td><td>{origin}</td><td>{result}</td></tr>')
page(section_title('01 / STANDARD-TYPE COVERAGE','Eighteen ordinary types.','Eevee covers Normal. Eight existing evolutions and nine new fan evolutions complete the ordinary types; the special Stellar branch follows on pages 12–14.')+
    '<table class="coverage"><thead><tr><th>Type</th><th>Family species</th><th>Status</th><th>Temporary Mega type</th></tr></thead><tbody>'+''.join(rows)+'</tbody></table>'+
    '<div class="note"><strong>Two type systems.</strong> This guide uses the eighteen Pokémon video-game types. The Pokémon TCG merges several of them into broader card-type categories; those categories do not replace the types used here.</div>'+
    '<div class="contents"><strong>Inside this collection</strong><p>New designs, Plate I · 3 &nbsp; / &nbsp; Plate II · 4–5<br>Existing family · 6 &nbsp; / &nbsp; Mega Eevee & Eonite · 7–11<br>Stellar branch · 12–14 &nbsp; / &nbsp; Art direction & references · 15</p></div>')

page(section_title('02 / NEW SPECIES · PLATE I','Four paths through the wild.','Original silhouettes, palettes and markings; each species remains a single type.')+
    '<div class="species-grid">'+''.join(new_record(p) for p in NEW[:4])+'</div>')

page(section_title('03 / NEW SPECIES · PLATE II','Stone, silk, mist, scale, silver.','Five more branches of Eevee’s adaptable family.')+
    art(1,'PLATE II · Strateon / Chryseon / Wraitheon / Wyrmeon / Ferreon','Five original fan-designed Eeveelutions: a layered sandstone Rock species, gold chitin Bug species, lilac Ghost species, indigo Dragon species and silver Steel species.')+
    '<div class="silhouette-list">'+''.join(f'<p>{badge(p["type"])} <strong>{p["name"]}</strong> — {p["category"]}</p>' for p in NEW[4:])+'</div>'+
    '<p class="small">The habitat scenes establish mood and behavior. These are bespoke creature concepts; no other fan character was used as a visual reference.</p>')

page(section_title('04 / NEW SPECIES · FIELD NOTES','Five distinct identities.','The final five fan evolutions complete the family’s missing types.')+
    '<div class="stacked-species">'+''.join(new_record(p,True) for p in NEW[4:])+'</div>')

page(section_title('05 / THE EXISTING FAMILY','Familiar faces. Fresh field notes.','Newly written entries for Eevee and its eight existing evolutions. Their established visual designs remain the reference.')+
    '<div class="existing-grid">'+''.join(f'<article class="existing-card" style="--type:{COLORS[p["type"]]}"><h3>{p["name"]}</h3>{badge(p['type'])}<div class="entry-label">Original Pokédex entry</div>{dex(p['entry'])}</article>' for p in EXISTING)+'</div>')

page(section_title('06 / MEGA CONVERGENCE','One body. Eighteen accents.','Only the little biological gem in the ruff varies by type.')+
    art(2,'PLATE III · The shared Mega Eevee, the invariant Eonite, and eighteen ruff-gem accents.','One sandy-brown Mega Eevee with a cream star-shaped ruff, one bushy tail and one small type gem; a separate opalescent Eonite with fixed inclusions; eighteen gem variations.')+
    '<div class="design-lock"><h3>The shared silhouette</h3><p>'+ESC(D['mega_design'])+'</p></div>'+
    '<p class="small"><strong>Identity:</strong> the source Pokémon remains the same individual and retains its single type. The change is temporary; its starting species returns after battle.</p>')

legend = ''.join(f'<div class="legend-item">{gem(p["type"],32)}<span><b>{p["type"]}</b><small>{p["motif"]}</small></span></div>' for p in MEGA)
page(section_title('07 / EONITE & ACTIVATION','The stone stays exactly the same.','Eonite is the held family Mega Stone. The small ruff gem belongs to the temporary body.')+
    '<div class="eonite-appearance"><h3>Eonite · appearance</h3><p>'+ESC(D['eonite']['appearance'])+'</p></div>'+
    '<div class="item"><div class="entry-label">In-game item description</div><p>'+ESC(D['eonite']['item_description'])+'</p></div>'+
    '<h3>How convergence works</h3><p>'+ESC(D['eonite']['rules'])+'</p>'+
    '<p>'+ESC(D['convergence'])+'</p>'+
    '<div class="mini-heading">EXACT RUFF-GEM KEY · COLORS & MOTIFS</div><div class="gem-legend">'+legend+'</div>'+
    '<p class="small">Eonite’s eighteen interior inclusions are fixed decorative features, independent of the eighteen Mega variants. They are never rearranged, selected or illuminated.</p>')

for i, group in enumerate([MEGA[:6],MEGA[6:12],MEGA[12:]]):
    page(section_title(f'08 / MEGA FIELD NOTES · {i+1} OF 3','Mega Eevee, observed.','Same sandy-brown body, cream star ruff and single luxuriant tail. Only the ruff gem shown here changes.')+
        '<div class="mega-grid">'+''.join(mega_record(p) for p in group)+'</div>'+
        ('<div class="note final-note"><strong>Eighteen forms, eighteen entries.</strong> Every source Pokémon retains its own single type. The held Eonite has one fixed appearance in every case.</div>' if i==2 else ''))

page(section_title('09 / SPECIAL STELLAR BRANCH','A new light on the horizon.','Novareon, its personal Mega form, and the fixed Novareonite.')+
    art(3,'PLATE IV · Novareon / Mega Novareon / Novareonite',STELLAR_ART_ALT)+
    '<div class="note stellar-canon">'+ESC(D['stellar_note'])+'</div>'+
    '<table class="coverage branch-table"><thead><tr><th>Special fan branch</th><th>Ordinary species</th><th>Personal Mega</th><th>Held stone</th></tr></thead><tbody><tr><td>'+badge('Stellar')+'</td><td>'+STELLAR['name']+'</td><td>'+PERSONAL['name']+'</td><td>'+STONE['name']+'</td></tr></tbody></table>'+
    '<p>'+ESC(D['stellar_mechanic'])+'</p>')

personal_record=f'''<article class="species-card personal-card" style="--type:{COLORS['Stellar']}">
  <div class="card-title"><h3>{PERSONAL['name']}</h3>{badge('Stellar')}</div>
  <div class="category">{PERSONAL['category']} · personal Mega form</div>
  <p class="etym"><strong>Source.</strong> {STELLAR['name']}, holding {STONE['name']}.</p>
  <p><strong>Visual design.</strong> {ESC(PERSONAL['design'])}</p>
  <div class="entry-label">Original Pokédex entry</div>{dex(PERSONAL['entry'])}
</article>'''
page(section_title('10 / STELLAR FIELD NOTES','Novareon & Mega Novareon.','Two distinct observations for a coherent ordinary-to-Mega progression.')+
    '<div class="stellar-records">'+new_record(STELLAR)+personal_record+'</div>'+
    '<div class="note stellar-progression"><strong>A restrained progression.</strong> Petrol-blue fur, warm ivory markings, amber eyes, folded ears and one continuous fan tail anchor both forms. Mega Evolution opens the shoulder folds and broadens the tail; it introduces no extra limbs, wings or detached ornaments.</div>')

page(section_title('11 / NOVAREONITE & ACTIVATION','A stone of its own.','The Stellar branch uses one personal Mega Stone, with one fixed appearance.')+
    '<div class="stone-profile"><h3>'+STONE['name']+' · appearance</h3><p>'+ESC(STONE['appearance'])+'</p></div>'+
    '<div class="item"><div class="entry-label">In-game item description</div><p>'+ESC(STONE['item_description'])+'</p></div>'+
    '<h3>Holding & activation</h3><p>'+ESC(STONE['rules'])+'</p>'+
    '<h3 class="paths-heading">Two distinct Mega paths</h3>'+
    '<table class="coverage stone-comparison"><thead><tr><th></th><th>Eonite</th><th>'+STONE['name']+'</th></tr></thead><tbody>'+
    '<tr><td>Eligible holder</td><td>Eevee + 17 standard-type evolutions</td><td>'+STELLAR['name']+'</td></tr>'+
    '<tr><td>Temporary result</td><td>Shared Mega Eevee · 18 single types</td><td>'+PERSONAL['name']+' · single Stellar</td></tr>'+
    '<tr><td>Fixed interior</td><td>Cream/brown curl + 18 colored inclusions</td><td>Ivory six-rayed star + copper ellipse + clear wedge</td></tr>'+
    '<tr><td>At activation</td><td>Appearance stays exactly the same</td><td>Appearance stays exactly the same</td></tr>'+
    '<tr><td>After battle</td><td>Returns to its starting species</td><td>Returns to '+STELLAR['name']+'</td></tr></tbody></table>'+
    '<div class="note"><strong>Complete collection:</strong> 19 ordinary family species + 19 Mega forms = 38 original Pokédex entries. Ten new evolutions comprise nine ordinary-type designs plus Novareon. The two stones have item descriptions, not Pokédex entries.</div>')

ref_list=''.join(f'<li><a href="{ESC(r["url"],quote=True)}">{ESC(r["label"])}</a><small class="url">{ESC(r["url"])}</small></li>' for r in D['references'])
page(section_title('12 / ART DIRECTION & COLLECTION NOTES','A coherent fan-made field guide.')+
    '<h3>Visual direction</h3><p>The illustrations draw on contemporary full-art and illustration-rare Pokémon TCG conventions: clean expressive linework, readable creature silhouettes, naturalistic painted habitats and luminous environmental light. They do not reproduce an official card or imitate a particular illustrator. No fake gameplay text is used.</p>'+
    '<h3>Original concepts</h3><p>All ten new species were conceived for this collection, with independent combinations of silhouettes, anatomy, markings, palettes and habitats. No other fan design was used as a visual reference.</p>'+
    '<h3>What is included</h3><p>Four illustrated boards; ten new species with names, etymologies, categories and visual descriptions; all eighteen ordinary types plus the special Stellar branch; thirty-eight fresh Pokédex entries; eighteen shared Mega Eevee variants and Mega Novareon; two fixed Mega Stones with item descriptions and activation rules.</p>'+
    '<div class="note"><strong>Unofficial fan work.</strong> Existing species and Pokémon terminology belong to their respective owners. The new species, Mega Stones and evolution mechanics are fan concepts. Illustrations were generated for this document; none is presented as official Pokémon art.</div>'+
    '<h3 class="references-heading">Official context</h3><p class="small">These official references document the existing family and illustrate general TCG art conventions. They are contextual links, not sources for the new fan species or proof that these designs appear in an official release.</p><ol class="references">'+ref_list+'</ol>'+
    '<p class="small endnote">Read offline in HTML, print the PDF, or edit the Markdown and structured content. All four artwork boards are bundled locally.</p>')

CSS = r'''
:root{--ink:#203d40;--muted:#65726e;--paper:#fcf8ef;--line:#ded5c4;--accent:#b88a4f}
*{box-sizing:border-box}html{background:#d9ded8}body{margin:0;color:var(--ink);font-family:"DejaVu Sans",Arial,sans-serif;font-size:10pt;line-height:1.46}
.sheet{position:relative;width:210mm;height:297mm;margin:9mm auto;padding:15mm 15mm 18mm;background:var(--paper);box-shadow:0 5px 30px #26332d19;break-after:page}
.sheet:last-child{break-after:auto}.running{display:flex;justify-content:space-between;font-size:6.8pt;letter-spacing:.13em;border-bottom:1px solid var(--line);padding-bottom:3mm;margin-bottom:7mm}.running span{font-size:6pt;color:var(--muted)}
footer{position:absolute;bottom:9mm;left:15mm;right:15mm;border-top:1px solid var(--line);padding-top:2mm;display:flex;justify-content:space-between;font-size:7pt;letter-spacing:.07em;color:var(--muted)}
.kicker{font-size:7pt;font-weight:700;letter-spacing:.15em;color:#9b774d;margin-bottom:2mm}h1,h2{font-family:"DejaVu Serif",Georgia,serif;font-weight:400;letter-spacing:-.035em;margin:0}h1{font-size:42pt;line-height:1.12}h1 em{font-style:normal;color:#886b43}h2{font-size:26pt;line-height:1.15;margin-bottom:3mm}h3{font-size:12.5pt;line-height:1.2;margin:0 0 2mm}p{margin:0 0 3mm}.deck{color:var(--muted);font-size:9.4pt;margin-bottom:7mm}.small{font-size:8pt;color:var(--muted)}
figure{margin:0 0 5mm}.board{width:100%;height:auto;display:block;border-radius:2mm}figcaption{font-size:6.8pt;letter-spacing:.06em;color:var(--muted);padding:2.6mm 0;border-bottom:1px solid var(--line)}
.cover-kicker{margin-top:3mm;margin-bottom:4mm}.cover-deck{font-size:10.3pt;color:var(--muted);margin:4mm 0 7mm}.cover figure{margin-bottom:4mm}.cover-intro{font-size:11pt;max-width:165mm}.stats{display:grid;grid-template-columns:repeat(4,1fr);border-top:1px solid var(--line);border-bottom:1px solid var(--line);padding:3mm 0;margin:5mm 0 4mm}.stats div{border-right:1px solid var(--line);padding-left:5mm}.stats div:first-child{padding-left:0}.stats div:last-child{border:0}.stats b{font-family:Georgia,serif;font-size:25pt;display:block;line-height:1.2;font-weight:400}.stats span{font-size:7.8pt;color:var(--muted)}
.badge{display:inline-flex;align-items:center;gap:1.5mm;font-size:7.2pt;letter-spacing:.02em;white-space:nowrap}.badge:before{content:"";width:2.2mm;height:2.2mm;border-radius:50%;background:var(--type);border:1px solid #0002}.coverage{border-collapse:collapse;width:100%;font-size:8.6pt;margin:4mm 0 6mm}.coverage th{text-align:left;font-size:7pt;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);padding:3mm 2mm;border-bottom:1px solid var(--ink)}.coverage td{padding:1.75mm 2mm;border-bottom:1px solid var(--line)}.coverage td:nth-child(4){font-size:7.5pt}.coverage tbody tr:nth-child(even){background:#eee8da50}.note{padding:4mm 5mm;background:#f0e9da;border-left:2px solid var(--accent);font-size:9pt}.contents{border-top:1px solid var(--line);margin-top:6mm;padding-top:4mm;font-size:8pt}.contents p{margin-top:2mm;color:var(--muted)}
.species-grid{display:grid;grid-template-columns:1fr 1fr;gap:5mm}.species-card{background:#fffdf7;border:1px solid var(--line);border-top:3px solid var(--type);border-radius:1.5mm;padding:4.5mm;font-size:9pt;break-inside:avoid}.species-grid .species-card{min-height:98mm}.card-title{display:flex;align-items:center;justify-content:space-between;gap:2mm}.card-title h3{font-family:Georgia,serif;font-size:19pt}.category{font-size:7.5pt;letter-spacing:.04em;color:var(--muted);margin-bottom:3mm}.etym{font-size:8.3pt;color:var(--muted)}.entry-label{font-size:6.2pt;letter-spacing:.1em;text-transform:uppercase;color:#9b774d;margin:3mm 0 1.5mm}.dex-entry{font-family:"DejaVu Serif",Georgia,serif;font-size:9.1pt;line-height:1.5;margin:0;padding:0;border:0}.silhouette-list{margin:6mm 0 7mm;columns:2;column-gap:12mm}.silhouette-list p{font-size:9.2pt;margin-bottom:4mm;break-inside:avoid}.silhouette-list .badge{margin-right:2mm}
.stacked-species{display:grid;grid-template-columns:1fr 1fr;gap:3mm}#page-5 .deck{margin-bottom:5mm}.stacked-species .compact:last-child{grid-column:1/-1}.compact{padding:2.8mm 4mm;font-size:8.4pt;line-height:1.38}.compact .card-title h3{font-size:15.5pt}.compact .category{margin-bottom:1mm;font-size:7pt}.compact .etym{font-size:7.8pt;margin-bottom:1.2mm}.compact p{margin-bottom:1.2mm}.compact .entry-label{margin-top:1.3mm;margin-bottom:1mm}.compact .dex-entry{font-size:8.5pt}.existing-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:4mm}.existing-card{padding:4mm;background:#fffdf7;border-top:3px solid var(--type);min-height:63mm}.existing-card h3{font-family:Georgia,serif;font-size:17pt}.existing-card .dex-entry{font-size:9.3pt}.design-lock{padding:4mm 5mm;border:1px solid var(--line);margin-bottom:4mm;font-size:9.1pt}.design-lock h3{font-family:Georgia,serif;font-size:14pt}.item{padding:3mm 5mm;background:#eee7d7;border-radius:2mm;margin:4mm 0 5mm;font-family:Georgia,serif;font-style:italic;font-size:11pt}.item .entry-label{font-family:Arial,sans-serif;font-style:normal;margin-top:0}.item p{margin:0}.eonite-appearance{font-size:9.2pt}.mini-heading{font-size:7pt;letter-spacing:.11em;font-weight:700;margin:5mm 0 3mm}.gem-legend{display:grid;grid-template-columns:repeat(4,1fr);gap:2.5mm 3mm;padding:3mm;border:1px solid var(--line);margin-bottom:3mm}.legend-item{display:flex;align-items:center;gap:2mm}.legend-item b{font-size:7.3pt;font-weight:500;display:block}.legend-item small{font-size:6.2pt;color:var(--muted);display:block;line-height:1.2}.gem{flex-shrink:0}
.mega-grid{display:grid;grid-template-columns:1fr 1fr;gap:4mm}.mega-card{min-height:62mm;padding:4mm;background:#fffdf7;border:1px solid var(--line);border-top:2px solid var(--type)}.mega-title{display:flex;gap:3mm;align-items:center;margin-bottom:2.5mm}.mega-title h3{font-family:Georgia,serif;font-size:17pt;margin-bottom:1mm}.mega-card .source,.mega-card .accent{font-size:8pt;margin-bottom:1.5mm}.mega-card .dex-entry{font-size:9.2pt}.mega-card .entry-label{margin-top:2.5mm}.final-note{margin-top:3mm;padding:3mm 4mm;font-size:8.3pt}.references-heading{margin-top:6mm}.references{padding-left:5mm;margin:3mm 0 6mm}.references li{font-size:8pt;padding-left:1mm;margin-bottom:3mm}.references a{color:#365b64;text-decoration:none}.url{display:block;font-size:6.5pt;color:var(--muted);overflow-wrap:anywhere;margin-top:.7mm}.endnote{border-top:1px solid var(--line);padding-top:4mm}
@page{size:A4;margin:0}@media print{html,body{background:white}.sheet{margin:0;box-shadow:none}.board{border-radius:0}a{color:inherit}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
@media screen and (max-width:820px){.sheet{margin:10px auto;transform-origin:top left}body{width:fit-content}.running span{letter-spacing:0}}
.stellar-canon{font-size:8.5pt;margin-top:4mm}.branch-table{margin-bottom:4mm}.branch-table td{font-size:8.2pt}.stellar-records{display:grid;grid-template-columns:1fr 1fr;gap:5mm}.stellar-records .species-card{min-height:136mm;font-size:9.5pt}.stellar-records .card-title{display:block}.stellar-records .card-title h3{font-size:21pt;margin-bottom:2mm}.stellar-records .category{margin-top:2mm}.stellar-records .dex-entry{font-size:10pt}.stellar-progression{margin-top:6mm;font-size:9pt}.stone-profile{padding:5mm;background:#f0f2ef;border-left:3px solid #446a7d;margin-bottom:5mm}.stone-profile p{margin-bottom:0}.paths-heading{margin-top:5mm}.stone-comparison th:first-child{width:26mm}.stone-comparison td{font-size:8.4pt;padding:3mm 2mm;vertical-align:top}.stone-comparison td:first-child{font-size:7.8pt;color:var(--muted)}
'''
html_doc = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="description" content="An unofficial Eevee fan collection: ten new evolutions, nineteen Mega forms, two fixed Mega Stones and thirty-eight original Pokédex entries. All eighteen ordinary types plus the special Stellar branch."><title>Eevee: New Horizons — Unofficial Fan Design Collection</title><style>'+CSS+'</style></head><body>'+''.join(pages)+'</body></html>'
assert html_doc.count('class="dex-entry"')==38
(ROOT/'Eevee-New-Horizons.html').write_text(html_doc)

md = [f'# {D["title"]}',f'*{D["subtitle"]}*','**Unofficial Pokémon fan work · Original concepts and AI-generated artwork.**','Not official Pokémon artwork, species or game content.',intro,'**Collection:** 10 new Eeveelutions · 19 ordinary family species · 19 Mega forms · 38 original Pokédex entries · 4 illustrated boards.','## Complete eighteen-ordinary-type coverage','This collection covers all eighteen ordinary Pokémon video-game types, plus the separate special Stellar fan branch. The Pokémon TCG merges several ordinary types into broader card-type categories; those merged categories are separate from this guide.','| Ordinary video-game type | Family species | Status | Mega source → single type |','|---|---|---|---|']
for t in ORDER:
    p=BY_TYPE[t]
    status='Base species' if t=='Normal' else ('New fan evolution' if p in NEW else 'Existing evolution')
    result=f'{p["name"]} → Mega Eevee ({t})'
    md.append(f'| {t} | {p["name"]} | {status} | {result} |')
md+=['### Special Stellar branch coverage','| Special fan branch | Ordinary species | Personal Mega | Held stone |\n|---|---|---|---|\n| Stellar | Novareon | Mega Novareon | Novareonite |','The Stellar branch is detailed below and uses its own personal Mega path.','## Nine ordinary-type fan Eeveelutions','![Plate I: Brawleon, Zephyreon, Venomeon and Duneon](art/01-new-evolutions.png)']
for i,p in enumerate(NEW):
    if i==4:
        md+=['![Plate II: Strateon, Chryseon, Wraitheon, Wyrmeon and Ferreon](art/02-new-evolutions.png)']
    md += [f'### {p["name"]} — {p["type"]}',f'**Category:** {p["category"]}',f'**Name derivation:** {p["derivation"]}',f'**Visual design:** {p["design"]}','**Original Pokédex entry**',f'> {p["entry"]}']
md+=['## The existing family — nine fresh entries','Existing species retain their established designs. All entries below were written for this collection.']
for p in EXISTING:
    md += [f'### {p["name"]} — {p["type"]}',f'> {p["entry"]}']
md+=['## Mega Eevee — convergence','![Plate III: shared Mega Eevee, invariant Eonite and eighteen ruff-gem accents](art/03-mega-convergence.png)',D['convergence'],'### The locked shared design',D['mega_design'],'## Eonite — the invariant family Mega Stone','### Appearance',D['eonite']['appearance'],'### In-game item description',f'*{D["eonite"]["item_description"]}*','### Holding and activation rules',D['eonite']['rules'],'Eonite’s eighteen fixed interior inclusions are decorative features, independent of the eighteen Mega variants. They are never rearranged, selected or illuminated.','## Eighteen Mega variants — original Pokédex entries','The body, fur, ears, eyes, tail, star-shaped ruff and main sandy-brown/cream palette remain identical. Only the little biological ruff gem’s color and engraved motif change.']
for p in MEGA:
    md += [f'### Mega Eevee — {p["type"]}',f'**Source species:** {p["sources"][0]} · **Type:** single {p["type"]}',f'**Ruff gem:** {p["color"]} ({p["hex"]}); {p["motif"].lower()}.',f'> {p["entry"]}']
md+=['## The special Stellar branch',f'![Plate IV: {STELLAR_ART_ALT}](art/04-novareon-stellar-branch.png)',D['stellar_note'],D['stellar_mechanic'],f'### {STELLAR["name"]} — single Stellar',f'**Category:** {STELLAR["category"]}',f'**Name derivation:** {STELLAR["derivation"]}',f'**Visual design:** {STELLAR["design"]}','**Original Pokédex entry**',f'> {STELLAR["entry"]}',f'### {PERSONAL["name"]} — single Stellar',f'**Source:** {STELLAR["name"]} holding {STONE["name"]}.',f'**Category:** {PERSONAL["category"]}',f'**Visual design:** {PERSONAL["design"]}','**Original Pokédex entry**',f'> {PERSONAL["entry"]}',f'### {STONE["name"]} — the fixed personal Mega Stone','**Appearance:** '+STONE['appearance'],'**In-game item description:** *'+STONE['item_description']+'*','**Holding and activation rules:** '+STONE['rules']]
md+=['## Art direction & originality','The illustrations draw on contemporary full-art and illustration-rare Pokémon TCG conventions: clean expressive contours, readable silhouettes, luminous painted habitats and restrained palettes. They do not reproduce an official card or imitate a particular illustrator. There are no fake card stats or gameplay text.','All ten new species were conceived for this collection with independent combinations of silhouette, anatomy, markings and palette. No other fan design was used as a visual reference.','## Official context references','The official links below document the existing family, general TCG rendering conventions and the canonical Stellar distinction. They are not sources for the fan species or evidence of an official release.']
md += [f'- [{r["label"]}]({r["url"]})' for r in D['references']]
md += ['## Files','- `Eevee-New-Horizons.html`: self-contained printable document, with all artwork embedded.\n- `Eevee-New-Horizons.pdf`: print-ready document.\n- `Eevee-New-Horizons.md`: editable guide; keep the neighboring `art` folder.\n- `art/`: the four final illustrated PNG boards.\n- `source/collection.json`: structured editable design content.\n- `source/build_document.py`: offline HTML and Markdown builder.','**Collection check:** 19 ordinary family species (Eevee + 8 existing evolutions + 9 ordinary-type fan evolutions + Novareon) + 19 Mega forms (18 shared Mega Eevee variants + Mega Novareon) = 38 original Pokédex entries. Eonite and Novareonite have item descriptions, not Pokédex entries.','Pokémon and existing characters belong to their respective owners. This collection is unofficial fan work.']
md_text='\n\n'.join(md)+'\n'
md_text=re.sub(r'(?m)^(\|[^\n]*\|)\n\n(?=\|)',r'\1\n',md_text)
assert sum(line.startswith('> ') for line in md_text.splitlines())==38
(ROOT/'Eevee-New-Horizons.md').write_text(md_text)
print(json.dumps({'html_pages':len(pages),'ordinary_species':len(EXISTING)+len(NEW_ALL),'new_evolutions':len(NEW_ALL),'shared_mega_eevee_variants':len(MEGA),'personal_mega_forms':len(D['mega_special']),'mega_forms_total':len(MEGA)+len(D['mega_special']),'original_entries':38,'html_bytes':len(html_doc.encode()),'markdown_bytes':len(md_text.encode())},indent=2))
