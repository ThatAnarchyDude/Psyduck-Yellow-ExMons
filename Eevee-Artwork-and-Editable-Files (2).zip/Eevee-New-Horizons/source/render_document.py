"""Render the self-contained local document and report page-layout checks."""
from pathlib import Path
import asyncio
import json
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parents[1]

async def main():
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
        page=await browser.new_page(viewport={'width':1000,'height':1300},device_scale_factor=1)
        await page.set_content((ROOT/'Eevee-New-Horizons.html').read_text(),wait_until='load')
        await page.evaluate('document.fonts.ready')
        await page.emulate_media(media='print')
        checks=await page.evaluate('''() => Array.from(document.querySelectorAll('.sheet')).map((s,i)=>{
          const box=s.getBoundingClientRect();
          const foot=s.querySelector('footer').getBoundingClientRect();
          const content=Array.from(s.querySelectorAll('*')).filter(x=>!x.closest('footer'));
          const bottom=Math.max(...content.map(x=>x.getBoundingClientRect().bottom));
          const overflow=content.filter(x=>x.getBoundingClientRect().right>box.right-30||x.getBoundingClientRect().left<box.left+30).map(x=>x.tagName+'.'+x.className).slice(0,6);
          return {page:i+1,bottom_space_px:Math.round(foot.top-bottom),footer_overlap:bottom>foot.top-20,horizontal_overflow:overflow};
        })''')
        await page.pdf(path=str(ROOT/'Eevee-New-Horizons.pdf'),print_background=True,prefer_css_page_size=True,display_header_footer=False)
        for n in range(1,len(checks)+1):
            await page.locator('.sheet').nth(n-1).screenshot(path=str(ROOT/f'previews/page-{n:02d}.png'))
        report={'pages':checks,'embedded_artwork':await page.locator('img.board').count(),'dex_entries':await page.locator('.dex-entry').count(),'images_loaded':await page.evaluate('Array.from(document.images).every(x=>x.complete&&x.naturalWidth>0)')}
        (ROOT/'source/layout-check.json').write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps(report,indent=2))
        await browser.close()

asyncio.run(main())
