# Eevee: New Horizons

An unofficial illustrated Pokémon fan-design collection.

- **10 new Eeveelutions**, alongside Eevee and its 8 existing evolutions.
- **19 ordinary family species**, covering all eighteen ordinary types plus the special Stellar fan branch.
- **19 single-type Mega forms:** 18 shared Mega Eevee variants, including Normal, plus the personal Mega Novareon.
- **38 original Pokédex entries**, plus separate item descriptions and activation rules for the two fixed Mega Stones.
- **4 illustrated design boards**, adding Novareon, Mega Novareon and Novareonite to the completed core collection.

Open **Eevee-New-Horizons.pdf** for the finished fifteen-page print edition. It uses A4 pages and includes all artwork.

Open **Eevee-New-Horizons.html** in a modern browser for the same printable document. It is self-contained: every artwork image is embedded, and no external fonts or assets are needed.

**Eevee-New-Horizons.md** is the editable written guide. Keep its neighboring **art** folder so the illustrations resolve. The four full-size PNG boards are also available individually in that folder.

The **source** folder contains the structured design content, offline document builder, PDF renderer and validation reports.

Only Mega Eevee's small biological ruff gem changes between its eighteen types. The held Eonite has one fixed appearance, including during activation, and its eighteen inclusions remain unchanged. Normal Mega Eevee comes from Eevee; the seventeen standard-type evolutions retain their own single types. Novareon uses its own fixed Novareonite to become Mega Novareon instead.

All new designs and entries were created for this unofficial collection. The artwork is AI-generated and is not official Pokémon art.
