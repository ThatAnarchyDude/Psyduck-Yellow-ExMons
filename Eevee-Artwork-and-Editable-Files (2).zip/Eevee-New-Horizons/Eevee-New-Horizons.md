# Eevee: New Horizons

*All eighteen ordinary types, plus a special Stellar fan branch*

**Unofficial Pokémon fan work · Original concepts and AI-generated artwork.**

Not official Pokémon artwork, species or game content.

Nine new evolutions complete all eighteen ordinary types. Novareon adds a special Stellar branch with its own Mega form and fixed Mega Stone.

**Collection:** 10 new Eeveelutions · 19 ordinary family species · 19 Mega forms · 38 original Pokédex entries · 4 illustrated boards.

## Complete eighteen-ordinary-type coverage

This collection covers all eighteen ordinary Pokémon video-game types, plus the separate special Stellar fan branch. The Pokémon TCG merges several ordinary types into broader card-type categories; those merged categories are separate from this guide.

| Ordinary video-game type | Family species | Status | Mega source → single type |
|---|---|---|---|
| Normal | Eevee | Base species | Eevee → Mega Eevee (Normal) |
| Fire | Flareon | Existing evolution | Flareon → Mega Eevee (Fire) |
| Water | Vaporeon | Existing evolution | Vaporeon → Mega Eevee (Water) |
| Electric | Jolteon | Existing evolution | Jolteon → Mega Eevee (Electric) |
| Grass | Leafeon | Existing evolution | Leafeon → Mega Eevee (Grass) |
| Ice | Glaceon | Existing evolution | Glaceon → Mega Eevee (Ice) |
| Fighting | Brawleon | New fan evolution | Brawleon → Mega Eevee (Fighting) |
| Poison | Venomeon | New fan evolution | Venomeon → Mega Eevee (Poison) |
| Ground | Duneon | New fan evolution | Duneon → Mega Eevee (Ground) |
| Flying | Zephyreon | New fan evolution | Zephyreon → Mega Eevee (Flying) |
| Psychic | Espeon | Existing evolution | Espeon → Mega Eevee (Psychic) |
| Bug | Chryseon | New fan evolution | Chryseon → Mega Eevee (Bug) |
| Rock | Strateon | New fan evolution | Strateon → Mega Eevee (Rock) |
| Ghost | Wraitheon | New fan evolution | Wraitheon → Mega Eevee (Ghost) |
| Dragon | Wyrmeon | New fan evolution | Wyrmeon → Mega Eevee (Dragon) |
| Dark | Umbreon | Existing evolution | Umbreon → Mega Eevee (Dark) |
| Steel | Ferreon | New fan evolution | Ferreon → Mega Eevee (Steel) |
| Fairy | Sylveon | Existing evolution | Sylveon → Mega Eevee (Fairy) |

### Special Stellar branch coverage

| Special fan branch | Ordinary species | Personal Mega | Held stone |
|---|---|---|---|
| Stellar | Novareon | Mega Novareon | Novareonite |

The Stellar branch is detailed below and uses its own personal Mega path.

## Nine ordinary-type fan Eeveelutions

![Plate I: Brawleon, Zephyreon, Venomeon and Duneon](art/01-new-evolutions.png)

### Brawleon — Fighting

**Category:** Surefoot Pokémon

**Name derivation:** Brawl + eon; strength expressed through balance and practiced footwork.

**Visual design:** An athletic russet quadruped with a cream brow and chest chevron, swept-back black-tipped ears, and dense brick-red fur. Broad dark forepaws have naturally thick knuckle fur, never gloves. A short muscular tail ends in a cream brush; its low, balanced stance supplies the fighting cue.

**Original Pokédex entry**

> Before crossing a swollen stream, it taps each stepping stone with a forepaw. Young Brawleon learn balance by copying the rhythm of an adult's steps.

### Zephyreon — Flying

**Category:** Slipstream Pokémon

**Name derivation:** Zephyr, a gentle wind, + eon.

**Visual design:** A light sky-blue and cloud-white quadruped with swept ears, featherlike fur fringes and white cheek tufts. Small graceful legs contrast with one broad, streaming tail of layered silky fur. Its airborne silhouette comes from long leaps and a spreading tail, without separate wings or extra limbs.

**Original Pokédex entry**

> It studies drifting seeds before leaping between cliffs. By spreading its tail fur, it can land on ledges scarcely wider than its paws.

### Venomeon — Poison

**Category:** Venom Dew Pokémon

**Name derivation:** Venom + eon; the narrow green secretion beads supply the visual cue.

**Visual design:** A sleek mulberry-purple quadruped with pale mint eyes, curved leaf-point ears and a narrow mint throat ruff. Tiny translucent jade droplets bead at its cheek-fur tips. One tapering plum tail ends in a small rounded green gland; the silhouette stays clean and feline.

**Original Pokédex entry**

> It leaves bitter droplets on the stems around its den. Hungry Pokémon quickly learn which plants to avoid, leaving a ring of untouched greenery around the entrance.

### Duneon — Ground

**Category:** Sand Listener Pokémon

**Name derivation:** Dune + eon; soft layered contours echo wind-shaped sand.

**Visual design:** A low sandy-ochre quadruped with broad digging forepaws, amber eyes, and chocolate ear interiors and muzzle. Two soft dune-shaped ridges form its neck ruff. Its one heavy tapering tail has a dark rounded tip and steadies the body on loose slopes.

**Original Pokédex entry**

> It sleeps with one forepaw buried in the sand. The tremors of an approaching herd wake it long before the Pokémon reach its burrow.

![Plate II: Strateon, Chryseon, Wraitheon, Wyrmeon and Ferreon](art/02-new-evolutions.png)

### Strateon — Rock

**Category:** Layered Pokémon

**Name derivation:** Strata, layers of rock, + eon.

**Visual design:** A compact sandstone-beige and terracotta quadruped, with naturally layered angular ears, rounded dark eyes and broad slate-gray paws. Three stepped mineral ridges make a short ruff; the single short tail ends in stacked facets. Rounded joints keep the stony creature warm and expressive.

**Original Pokédex entry**

> It beds down against cliffs whose layers match the ridges on its neck. By morning, the heat stored in its body has drawn small Pokémon out of the cracks.

### Chryseon — Bug

**Category:** Chrysalis Pokémon

**Name derivation:** Chrysalis + eon; its gold coloration also recalls the Greek chrysos, meaning gold.

**Visual design:** A honey-gold and muted olive quadruped with amber feet, golden eyes, long leaf-shaped ears and a pair of fine amber antennae. Three overlapping chitin petals form a chrysalis-shaped chest ruff. Subtle waist bands and a single curled, leaf-veined tail imply insect structure; it has four legs and no wings.

**Original Pokédex entry**

> At dusk, it rubs the edges of its neck plates together. The soft ticking guides its scattered young back through the undergrowth without attracting predatory Pokémon.

### Wraitheon — Ghost

**Category:** Wayside Pokémon

**Name derivation:** Wraith + eon; a gentle, watchful apparition rather than a skeletal design.

**Visual design:** A smoky-lilac quadruped with a solid readable torso, long pale-tipped ears, deep violet eyes and a cream crescent throat tuft. Wispy fur softens four distinct paws and the edges of one long curling tail. The calm face and mist-fringed outline suggest a companion at a quiet woodland crossroads.

**Original Pokédex entry**

> It waits beside paths that disappear beneath autumn leaves. Travelers who follow the sweep of its tail find themselves back on firm ground before the mist lifts.

### Wyrmeon — Dragon

**Category:** Ridgekeeper Pokémon

**Name derivation:** Wyrm, an old word for a dragon, + eon.

**Visual design:** A supple indigo quadruped with a pale apricot chest, amber eyes, and small smooth scales among short fur. Its large ears have modest swept-back hornlike tips. A low dorsal ridge leads to one long muscular tail with an ivory tuft. No wings, forehead horns or additional limbs interrupt the dragon-fox outline.

**Original Pokédex entry**

> It rolls loose stones away from the ledge where it nests. The oldest Wyrmeon maintain clear paths across ridges that other Pokémon would never attempt alone.

### Ferreon — Steel

**Category:** Tempered Pokémon

**Name derivation:** Ferrum, Latin for iron, + eon.

**Visual design:** An elegant brushed-silver quadruped with short charcoal fur at its joints, tall tapered ears and warm copper eyes. Overlapping biological metal leaves form a flexible neck ruff. Four compact dark paws and one smooth tapered metallic tail complete the clean silhouette; there are no bolts, machines or worn armor.

**Original Pokédex entry**

> It polishes its neck plates against smooth river stones. A dull patch tells the group that one of its members has not visited the water for several days.

## The existing family — nine fresh entries

Existing species retain their established designs. All entries below were written for this collection.

### Eevee — Normal

> Before settling into a new den, it gathers a mouthful of local grass. The scent helps it recognize the entrance even after rain has washed its tracks away.

### Vaporeon — Water

> It rests where a stream meets a lake, facing into the current. A twitch of its tail sends small aquatic Pokémon away from stretches where the water has turned foul.

### Jolteon — Electric

> On dry evenings, it brushes its flanks against tall grass to release excess charge. The faint crackling draws curious young Pokémon, which it warns away with a stamp.

### Flareon — Fire

> It turns its back to the wind while its companions sleep against its ruff. Before dawn, it moves aside so the youngest can reach the warmest patch of ground.

### Espeon — Psychic

> It chooses a sunny resting place with a clear view of every approach. Even with its eyes closed, its ears turn toward footsteps that have not yet reached the path.

### Umbreon — Dark

> It walks the same woodland boundary each night, pausing wherever a familiar scent has changed. Its rings brighten briefly when it finds a lost member of its group.

### Leafeon — Grass

> It settles beside damaged saplings and loosens the soil with its forepaws. New shoots often appear in the shallow hollows where it has spent the afternoon.

### Glaceon — Ice

> It keeps a cache of berries beneath a thin lid of ice. When food grows scarce, it breaks the lid with one paw and leaves the smallest berries for visiting Pokémon.

### Sylveon — Fairy

> It trails a feeler along a nervous companion's shoulder as they walk. If the companion stops trembling, Sylveon loosens its hold but stays close until they reach shelter.

## Mega Eevee — convergence

![Plate III: shared Mega Eevee, invariant Eonite and eighteen ruff-gem accents](art/03-mega-convergence.png)

In this unofficial convergence mechanic, Eevee and the seventeen standard-type evolved species temporarily become the same Mega Eevee design while retaining their own single Pokémon type. Eevee produces the Normal Mega variant; each standard-type evolution produces the variant of its existing type. There are eighteen eligible source species and eighteen distinct single-type Mega variants. No new type and no dual typing are introduced. The temporary return to Eevee's family silhouette is not devolution; after battle, the Pokémon returns to its starting species.

### The locked shared design

One recognizably Eevee-like quadruped, with a warm sandy-brown body, long ears with dark-brown interiors, dark amber eyes, a large cream star-shaped fur ruff, four compact paws and one luxuriant brown tail with a cream tip. A single small octagonal faceted biological gem sits at the front of the ruff. Only this little gem's color and simple engraved type motif vary. Body shape, size, fur, eyes, ears, tail, ruff and main palette are identical in all eighteen variants. The biological ruff gem is part of the temporary Mega body; it is not Eonite and is not a second held stone.

## Eonite — the invariant family Mega Stone

### Appearance

A translucent, opalescent ovoid Mega Stone. A cream-and-brown double-helix curl, swept into a comet-like loop, is suspended inside it. Eighteen tiny colored inclusions sit permanently around its interior. The stone's shape, colors, curl, inclusions and reflected pearly sheen are identical for every holder, before, during and after activation. It never glows, recolors, pulses, changes a rune, rearranges inclusions or otherwise visibly reacts.

### In-game item description

*A Mega Stone to be held by Eevee or an Evolution of Eevee. A Trainer's Key Stone enables Mega Evolution.*

### Holding and activation rules

Eevee or any of the seventeen standard-type evolutions holds Eonite; its Trainer carries a Key Stone and deliberately activates their bond in battle. The stone is not consumed, and follows the usual one-Mega-Evolution-per-Trainer-per-battle limit. The holder's starting species determines its single Mega type automatically: Eevee produces the Normal variant, and every Eeveelution retains its own type. Eonite offers no type selection, random switch or visible reaction. The transformation is temporary and ends after battle, returning the Pokémon to the exact species that began the battle. It does not permanently evolve, devolve or merge the species.

Eonite’s eighteen fixed interior inclusions are decorative features, independent of the eighteen Mega variants. They are never rearranged, selected or illuminated.

## Eighteen Mega variants — original Pokédex entries

The body, fur, ears, eyes, tail, star-shaped ruff and main sandy-brown/cream palette remain identical. Only the little biological ruff gem’s color and engraved motif change.

### Mega Eevee — Normal

**Source species:** Eevee · **Type:** single Normal

**Ruff gem:** Pearl white (#e9e1ce); ring.

> It changes its daily route when food becomes scarce. A sideways sweep of its tail tells the following group to spread out and forage.

### Mega Eevee — Fire

**Source species:** Flareon · **Type:** single Fire

**Ruff gem:** Vermilion (#dc5b3c); flame.

> It lies across a frost-covered trail until a narrow strip of soil thaws beneath it. Small bird Pokémon follow behind, searching the newly softened ground for seeds.

### Mega Eevee — Water

**Source species:** Vaporeon · **Type:** single Water

**Ruff gem:** Sapphire blue (#3e89bd); droplet.

> It holds a pocket of air within its dense ruff while swimming. Small aquatic Pokémon shelter beneath its trailing tail when a passing current stirs the riverbed.

### Mega Eevee — Electric

**Source species:** Jolteon · **Type:** single Electric

**Ruff gem:** Golden yellow (#eac34d); lightning bolt.

> It presses all four paws firmly into bare soil before a storm arrives. Pokémon resting nearby are spared the prickling shocks that otherwise jump between their coats.

### Mega Eevee — Grass

**Source species:** Leafeon · **Type:** single Grass

**Ruff gem:** Leaf green (#63a66a); leaf.

> Burrs cling to its luxuriant tail as it moves through scrub. It chooses damp, bare patches for grooming, scattering the seeds where new plants can take root.

### Mega Eevee — Ice

**Source species:** Glaceon · **Type:** single Ice

**Ruff gem:** Icy cyan (#81cdd9); snowflake.

> It draws warmth from the wet earth beside its resting place. Meltwater freezes into a shallow basin there, preserving drinking water through the next day's dry winds.

### Mega Eevee — Fighting

**Source species:** Brawleon · **Type:** single Fighting

**Ruff gem:** Brick red (#b85449); crossed strokes.

> It stamps twice before a sparring match, then waits for its partner to find firm footing. Even at full strength, it halts a charge when the other Pokémon stumbles.

### Mega Eevee — Poison

**Source species:** Venomeon · **Type:** single Poison

**Ruff gem:** Amethyst purple (#9b68b6); three dots.

> It noses through fallen fruit and pushes spoiled pieces away from shared feeding places. Toxins that would sicken its companions pass through its body without troubling it.

### Mega Eevee — Ground

**Source species:** Duneon · **Type:** single Ground

**Ruff gem:** Ochre (#bc9252); two horizontal ridges.

> At dawn, it lays one long ear against the ground and listens. It digs only after hearing the faint movement of water beneath an otherwise barren slope.

### Mega Eevee — Flying

**Source species:** Zephyreon · **Type:** single Flying

**Ruff gem:** Pale periwinkle (#9bafdb); curved wind stroke.

> It angles its long ears into a crosswind to turn during a leap. A slight twist of its broad tail lets it settle among nesting Pokémon without shaking their branch.

### Mega Eevee — Psychic

**Source species:** Espeon · **Type:** single Psychic

**Ruff gem:** Rose pink (#d782a6); spiral.

> While it dozes, loose pebbles arrange themselves around its paws. If a sleeping companion rolls toward the edge of a ledge, the stones gather quietly in its path.

### Mega Eevee — Bug

**Source species:** Chryseon · **Type:** single Bug

**Ruff gem:** Lime green (#b1bf54); paired antenna strokes.

> It rests its chin against hollow branches to feel the movements inside. It leaves occupied wood undisturbed, returning only after the young Bug Pokémon have emerged.

### Mega Eevee — Rock

**Source species:** Strateon · **Type:** single Rock

**Ruff gem:** Warm slate (#9c8e7d); triangle.

> It braces its shoulder beneath loose stones near its den. By shifting them a little each night, it builds a low wall that turns falling scree away from the entrance.

### Mega Eevee — Ghost

**Source species:** Wraitheon · **Type:** single Ghost

**Ruff gem:** Lavender (#b39acb); crescent.

> Its ears follow the footsteps of companions that are no longer there. At dusk, it leaves a space beside its tail, and the grass in that spot sometimes bends.

### Mega Eevee — Dragon

**Source species:** Wyrmeon · **Type:** single Dragon

**Ruff gem:** Royal indigo (#6667b4); angular chevron.

> It answers distant calls with a low hum felt through the ground. Young mountain Pokémon press their paws to the rock to learn which valleys are already occupied.

### Mega Eevee — Dark

**Source species:** Umbreon · **Type:** single Dark

**Ruff gem:** Charcoal (#505460); eclipsed circle.

> It crosses open ground only after studying the shadows cast by passing clouds. Following its example, the rest of its group can travel unseen even in daylight.

### Mega Eevee — Steel

**Source species:** Ferreon · **Type:** single Steel

**Ruff gem:** Silver (#adb7bc); hexagon.

> It holds an ear close to a cracked stone and listens to the ringing within. Miners watch where it refuses to place a paw before opening a new passage.

### Mega Eevee — Fairy

**Source species:** Sylveon · **Type:** single Fairy

**Ruff gem:** Soft blush (#e4a6bd); four-point star.

> It greets an unfamiliar group by lowering its head until its ruff brushes the grass. Even wary Pokémon will approach to exchange scents before either side begins feeding.

## The special Stellar branch

![Plate IV: Original petrol-blue and ivory Novareon with a three-wedge fan tail; Mega Novareon with a rounded petrol-blue fan, eight clockwise fur motifs including a black bottom wedge, and a broad gradual rump-to-center junction; circular smoked-blue Novareonite with an ivory six-ray star and copper elliptical inner orbit.](art/04-novareon-stellar-branch.png)

Stellar is a special Terastal type in canon. Giving Novareon and Mega Novareon intrinsic single Stellar typing is this collection’s explicit fan rule.

Novareon holds its own Novareonite to become Mega Novareon. This personal Mega branch is separate from Eonite convergence: it adds no nineteenth Mega Eevee accent and makes no change to Eonite or its eighteen fixed inclusions.

### Novareon — single Stellar

**Category:** Star Chart Pokémon

**Name derivation:** Nova, a star's sudden brilliant brightening, + eon.

**Visual design:** A compact petrol-blue quadruped with a warm ivory muzzle and belly, amber eyes and a plain forehead. Broad ears fold outward at their bases before tapering up; cream rims have small dark notches. Two short triangular cream fur folds sweep backward along its shoulders. An off-center arc of pearl flecks crosses one shoulder. Its single flattened brush tail has a rounded fan tip marked with three ivory wedges; four dark paws have ivory toe tips.

**Original Pokédex entry**

> At dusk, it aligns its broad tail with the first star to appear. Even under heavy cloud, it can lead its group back to the same resting hollow.

### Mega Novareon — single Stellar

**Source:** Novareon holding Novareonite.

**Category:** Star Chart Pokémon

**Visual design:** A moderately larger, slightly longer-legged Novareon, retaining its petrol-blue and ivory palette, amber eyes and plain forehead. The same folded ears stand more upright. Its shoulder bib opens into six short overlapping cream fur planes swept backward, while the shoulder flecks form two offset rows. One broad, convex plush fan tail sits lowered and close behind the rump, with rounded depth, a body-matching petrol-blue field and thin gold trim. Its short, broad body-blue furry root flares gradually from the rump into the central blue inter-wedge spaces, without a pointed connector or outer-edge attachment. Eight curved painted-fur motifs circle the rim clockwise: white at top, green, vivid blue, purple, black at bottom, yellow, orange and red. Wide blue gaps separate outward-pointed heads; inward tapers swirl clockwise, white bending picture-right and black picture-left. Four dark paws retain ivory toe tips; the progression adds no wings, floating objects or extra tails.

**Original Pokédex entry**

> It spreads its broad tail beside mountain pools, reflecting starlight onto the shallows. Small nocturnal Pokémon gather at the bright edge to drink, then slip away beneath its ruff.

### Novareonite — the fixed personal Mega Stone

**Appearance:** A front-on circular Mega Stone of translucent smoked midnight-blue, with equal height and width, a smooth round perimeter and fine facets giving depth. One stationary ivory six-rayed star sits inside a fine copper elliptical loop with two tiny copper knots; a tiny clear prismatic wedge rests near the lower inner edge. Its shape, colors, internal star, loop, wedge and reflected sheen stay exactly the same before, during and after activation. It never glows, pulses or changes color.

**In-game item description:** *A Mega Stone to be held by Novareon. A Trainer's Key Stone enables it to Mega Evolve into Mega Novareon.*

**Holding and activation rules:** Novareon holds Novareonite while its Trainer carries a Key Stone. Deliberate activation in battle temporarily produces Mega Novareon, retaining single Stellar typing; after battle it returns to Novareon. The stone is not consumed and never visibly reacts. This uses the same one-Mega-Evolution-per-Trainer-per-battle allowance as Eonite, so the two paths cannot both be activated by one Trainer in that battle. Novareonite is specific to Novareon.

## Art direction & originality

The illustrations draw on contemporary full-art and illustration-rare Pokémon TCG conventions: clean expressive contours, readable silhouettes, luminous painted habitats and restrained palettes. They do not reproduce an official card or imitate a particular illustrator. There are no fake card stats or gameplay text.

All ten new species were conceived for this collection with independent combinations of silhouette, anatomy, markings and palette. No other fan design was used as a visual reference.

## Official context references

The official links below document the existing family, general TCG rendering conventions and the canonical Stellar distinction. They are not sources for the fan species or evidence of an official release.

- [Official Eevee Pokédex — existing evolutionary family](https://www.pokemon.com/us/pokedex/eevee)

- [Official TCG art context — 30th Celebration product showcase](https://www.pokemon.com/us/news/pokemon-tcg-30th-celebration-product-showcase)

- [Official TCG art context — 30th Celebration Pikachu card illustrations](https://www.pokemon.com/us/news/look-at-electrifying-pikachu-cards-from-pokemon-tcg-30th-celebration)

- [Official TCG art context — Mega Evolution—Chaos Rising art feature](https://www.pokemon.com/us/features/art-of-the-pokemon-tcg-mega-evolution-chaos-rising-expansion)

- [Official Nintendo context — Stellar as a special Tera Type](https://www.nintendo.com/us/store/products/the-hidden-treasure-of-area-zero-dlc-for-pokemon-scarlet-70070000016943-switch/)

## Files

- `Eevee-New-Horizons.html`: self-contained printable document, with all artwork embedded.
- `Eevee-New-Horizons.pdf`: print-ready document.
- `Eevee-New-Horizons.md`: editable guide; keep the neighboring `art` folder.
- `art/`: the four final illustrated PNG boards.
- `source/collection.json`: structured editable design content.
- `source/build_document.py`: offline HTML and Markdown builder.

**Collection check:** 19 ordinary family species (Eevee + 8 existing evolutions + 9 ordinary-type fan evolutions + Novareon) + 19 Mega forms (18 shared Mega Eevee variants + Mega Novareon) = 38 original Pokédex entries. Eonite and Novareonite have item descriptions, not Pokédex entries.

Pokémon and existing characters belong to their respective owners. This collection is unofficial fan work.
