This smaller package contains all four original PNG artwork boards and the editable Markdown guide, structured content and rebuild scripts.
The PDF and self-contained HTML guide are supplied as separate downloads to keep the ZIP smaller.
